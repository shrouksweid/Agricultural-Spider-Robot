/* ==========================================================
   Agricultural Spider Robot — IoT Integrated
   ESP32 Version

   This sketch combines the spider robot hardware control
   with WiFi, an AsyncWebServer (serving the IoT dashboard),
   and MQTT communication (HiveMQ public broker).

   Dashboard topics:
     Subscribe  spider/move      (forward|backward|left|right|stop)
     Subscribe  spider/behavior  (stand|sleep|angry|happy|dance)
     Subscribe  spider/tool      (sprayer_on|sprayer_off|cutter_on|cutter_off)
     Publish    spider/status    (JSON telemetry every 2 s)

   Modes:
     Happy, Dance, Angry, Sleep, Sprayer, Cutter
     Forward, Backward, Left, Right, Stop (stand)
========================================================== */

#include <Arduino.h>
#include <WiFi.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>
#include <ESPAsyncWebServer.h>
#include <PubSubClient.h>

// Include the dashboard HTML served from PROGMEM
#include "dashboard_html.h"

// =======================================================
//  WiFi Credentials  —  UPDATE BEFORE FLASHING
// =======================================================

const char *WIFI_SSID = "YOUR_SSID";
const char *WIFI_PASS = "YOUR_PASSWORD";

// =======================================================
//  MQTT Configuration
// =======================================================

const char *MQTT_BROKER   = "broker.hivemq.com";
const int   MQTT_PORT     = 1883;
const char *MQTT_CLIENT   = "spider_esp32_";   // random suffix added at runtime

const char *TOPIC_MOVE     = "spider/move";
const char *TOPIC_BEHAVIOR = "spider/behavior";
const char *TOPIC_TOOL     = "spider/tool";
const char *TOPIC_STATUS   = "spider/status";

// =======================================================
//  OLED
// =======================================================

#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT  64
#define OLED_RESET     -1
#define SCREEN_ADDRESS 0x3C

Adafruit_SSD1306 display(
    SCREEN_WIDTH,
    SCREEN_HEIGHT,
    &Wire,
    OLED_RESET
);

// =======================================================
//  Servo Objects
// =======================================================

Servo servo[8];

// =======================================================
//  Sprayer & Cutter Pins
// =======================================================

#define SPRAYER_PIN  4
#define CUTTER_IN1  16
#define CUTTER_IN2  17

// =======================================================
//  Servo Pins
// =======================================================

const uint8_t servoPins[8] = {
    13, // R1
    12, // R2
    14, // L1
    27, // L2
    26, // R4
    25, // R3
    33, // L3
    32  // L4
};

// =======================================================
//  Servo Mapping
// =======================================================

enum ServoName : uint8_t {
    R1 = 0,
    R2 = 1,
    L1 = 2,
    L2 = 3,
    R4 = 4,
    R3 = 5,
    L3 = 6,
    L4 = 7
};

// =======================================================
//  Face Animation
// =======================================================

enum FaceAnimMode : uint8_t {
    FACE_ANIM_LOOP,
    FACE_ANIM_ONCE,
    FACE_ANIM_BOOMERANG
};

String currentFace          = "stand";
unsigned long lastAnimUpdate = 0;
int animationFrame           = 0;

// =======================================================
//  Global State
// =======================================================

String currentCommand  = "";       // pending command from MQTT
String currentState    = "stand";  // last-known robot state for telemetry
bool   sprayerOn       = false;
bool   cutterOn        = false;

// =======================================================
//  Networking Objects
// =======================================================

WiFiClient      espClient;
PubSubClient    mqttClient(espClient);
AsyncWebServer  server(80);

String mqttClientId;                // built once in setup()

unsigned long lastTelemetry     = 0;
const unsigned long TELEMETRY_MS = 2000;

unsigned long lastWifiCheck     = 0;
const unsigned long WIFI_CHECK_MS = 10000;

// ======================================================
//  Face Drawing
// ======================================================

void drawEyes(int eyeHeight, int pupYOffset = 0) {

    display.clearDisplay();

    display.fillRoundRect(
        20,
        32 - (eyeHeight / 2) + pupYOffset,
        30,
        eyeHeight,
        8,
        SSD1306_WHITE
    );

    display.fillRoundRect(
        78,
        32 - (eyeHeight / 2) + pupYOffset,
        30,
        eyeHeight,
        8,
        SSD1306_WHITE
    );

    display.display();
}

void drawAngryEyes() {

    display.clearDisplay();

    display.fillRoundRect(20, 20, 30, 25, 4, SSD1306_WHITE);
    display.fillRoundRect(78, 20, 30, 25, 4, SSD1306_WHITE);

    display.fillTriangle(20, 20, 50, 20, 20, 30, SSD1306_BLACK);
    display.fillTriangle(78, 20, 108, 20, 108, 30, SSD1306_BLACK);

    display.display();
}

void drawWalkEyes() {

    display.clearDisplay();

    // focused / determined look — slightly narrower eyes
    display.fillRoundRect(20, 24, 30, 18, 6, SSD1306_WHITE);
    display.fillRoundRect(78, 24, 30, 18, 6, SSD1306_WHITE);

    display.display();
}

// ======================================================
//  Face Animation
// ======================================================

void updateFaceAnimation() {

    if (millis() - lastAnimUpdate < 100)
        return;

    lastAnimUpdate = millis();

    if (currentFace == "stand"   ||
        currentFace == "Happy"   ||
        currentFace == "Dance"   ||
        currentFace == "Sprayer" ||
        currentFace == "Cutter") {

        if      (animationFrame == 0) drawEyes(25);
        else if (animationFrame == 1) drawEyes(15);
        else if (animationFrame == 2) drawEyes(5);
        else                          drawEyes(15);

        animationFrame = (animationFrame + 1) % 4;
    }
    else if (currentFace == "Angry") {
        drawAngryEyes();
    }
    else if (currentFace == "Sleep") {
        drawEyes(4);
    }
    else if (currentFace == "Walk") {
        drawWalkEyes();
    }
    else {
        drawEyes(25);
    }
}

// ======================================================

void delayWithFace(unsigned long ms) {

    unsigned long start = millis();

    while (millis() - start < ms) {
        updateFaceAnimation();
        mqttClient.loop();      // keep MQTT alive during delays
        delay(10);
    }
}

// ======================================================

void setFaceWithMode(const String &faceName, FaceAnimMode mode) {

    currentFace    = faceName;
    animationFrame = 0;

    updateFaceAnimation();
}

// ======================================================

void setServoAngle(uint8_t channel, int angle) {

    servo[channel].write(angle);
    delay(20);
}

// ======================================================
//  Stand Pose
// ======================================================

void runStandPose(bool smooth) {

    setServoAngle(R1, 135);
    setServoAngle(R2,  45);

    setServoAngle(L1,  45);
    setServoAngle(L2, 135);

    setServoAngle(R4,  60);
    setServoAngle(R3, 120);

    setServoAngle(L3,  60);
    setServoAngle(L4, 120);

    if (smooth)
        delayWithFace(300);
}

// ======================================================
//  Happy Pose
// ======================================================

void runHappyPose() {

    Serial.println("HAPPY");
    currentState = "happy";

    setFaceWithMode("Happy", FACE_ANIM_ONCE);
    runStandPose(false);
    delayWithFace(200);

    setServoAngle(R4, 90);
    setServoAngle(L3, 135);
    setServoAngle(L2, 90);
    setServoAngle(R1, 100);
    delayWithFace(200);

    for (int i = 0; i < 4; i++) {
        setServoAngle(L3, 135);
        delayWithFace(300);
        setServoAngle(L3, 90);
        delayWithFace(300);
    }

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

// ======================================================
//  Dance Pose
// ======================================================

void runDancePose() {

    Serial.println("DANCE");
    currentState = "dance";

    setFaceWithMode("Dance", FACE_ANIM_LOOP);

    for (int i = 0; i < 5; i++) {
        setServoAngle(R4,  90);
        setServoAngle(R3,  90);
        setServoAngle(L3,  60);
        setServoAngle(L4,  60);
        delayWithFace(300);

        setServoAngle(R4, 120);
        setServoAngle(R3, 120);
        setServoAngle(L3,  90);
        setServoAngle(L4,  90);
        delayWithFace(300);
    }

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

// ======================================================
//  Sprayer Pose
// ======================================================

void runSprayerPose() {

    Serial.println("SPRAYER");
    currentState = "sprayer";
    sprayerOn    = true;

    setFaceWithMode("Sprayer", FACE_ANIM_LOOP);
    runStandPose(true);

    digitalWrite(SPRAYER_PIN, HIGH);
    delayWithFace(3000);
    digitalWrite(SPRAYER_PIN, LOW);

    sprayerOn = false;
    delayWithFace(500);

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

// ======================================================
//  Angry Pose
// ======================================================

void runAngryPose() {

    Serial.println("ANGRY");
    currentState = "angry";

    setFaceWithMode("Angry", FACE_ANIM_ONCE);
    runStandPose(false);
    delayWithFace(200);

    setServoAngle(L1,  30);
    setServoAngle(R1, 150);
    delayWithFace(1500);

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

// ======================================================
//  Sleep Pose
// ======================================================

void runSleepPose() {

    Serial.println("SLEEP");
    currentState = "sleep";

    setFaceWithMode("Sleep", FACE_ANIM_BOOMERANG);
    runStandPose(true);
    delayWithFace(3000);

    currentState   = "stand";
    currentCommand = "";
}

// ======================================================
//  Cutter Pose
// ======================================================

void runCutterPose() {

    Serial.println("CUTTER");
    currentState = "cutter";
    cutterOn     = true;

    setFaceWithMode("Cutter", FACE_ANIM_LOOP);
    runStandPose(true);

    digitalWrite(CUTTER_IN1, HIGH);
    digitalWrite(CUTTER_IN2, LOW);
    delayWithFace(3000);
    digitalWrite(CUTTER_IN1, LOW);
    digitalWrite(CUTTER_IN2, LOW);

    cutterOn = false;

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

// ======================================================
//  Movement Gaits
// ======================================================

/*
 * Leg layout (top view, robot facing up):
 *
 *   L1 (hip)  L2 (knee)  ---|--- R1 (hip)  R2 (knee)     FRONT
 *   L3 (hip)  L4 (knee)  ---|--- R3 (hip)  R4 (knee)     REAR
 *
 * Alternating-diagonal gait: move (L1+R3) together,
 * then (R1+L3) together — classic "trot" for 4-legged bots.
 */

void runForwardGait() {

    Serial.println("FORWARD");
    currentState = "forward";
    setFaceWithMode("Walk", FACE_ANIM_LOOP);

    for (int step = 0; step < 4; step++) {

        // Phase A: lift L1+R3 pair, swing forward
        setServoAngle(L2, 100);   // L-front knee lift
        setServoAngle(R4,  90);   // R-rear knee lift
        delayWithFace(100);

        setServoAngle(L1,  30);   // L-front hip forward
        setServoAngle(R3, 135);   // R-rear hip forward
        delayWithFace(100);

        setServoAngle(L2, 135);   // L-front knee down
        setServoAngle(R4,  60);   // R-rear knee down
        delayWithFace(100);

        // Phase B: lift R1+L3 pair, swing forward
        setServoAngle(R2,  80);   // R-front knee lift
        setServoAngle(L4, 150);   // L-rear knee lift
        delayWithFace(100);

        setServoAngle(R1, 150);   // R-front hip forward
        setServoAngle(L3,  45);   // L-rear hip forward
        delayWithFace(100);

        setServoAngle(R2,  45);   // R-front knee down
        setServoAngle(L4, 120);   // L-rear knee down
        delayWithFace(100);

        // Reset hips to neutral for next cycle
        setServoAngle(L1,  45);
        setServoAngle(R1, 135);
        setServoAngle(R3, 120);
        setServoAngle(L3,  60);
        delayWithFace(80);
    }

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

void runBackwardGait() {

    Serial.println("BACKWARD");
    currentState = "backward";
    setFaceWithMode("Walk", FACE_ANIM_LOOP);

    for (int step = 0; step < 4; step++) {

        // Phase A: lift L1+R3 pair, swing backward
        setServoAngle(L2, 100);
        setServoAngle(R4,  90);
        delayWithFace(100);

        setServoAngle(L1,  60);   // hip backward (opposite of forward)
        setServoAngle(R3, 105);
        delayWithFace(100);

        setServoAngle(L2, 135);
        setServoAngle(R4,  60);
        delayWithFace(100);

        // Phase B: lift R1+L3 pair, swing backward
        setServoAngle(R2,  80);
        setServoAngle(L4, 150);
        delayWithFace(100);

        setServoAngle(R1, 120);
        setServoAngle(L3,  75);
        delayWithFace(100);

        setServoAngle(R2,  45);
        setServoAngle(L4, 120);
        delayWithFace(100);

        // Reset hips to neutral
        setServoAngle(L1,  45);
        setServoAngle(R1, 135);
        setServoAngle(R3, 120);
        setServoAngle(L3,  60);
        delayWithFace(80);
    }

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

void runTurnLeftGait() {

    Serial.println("LEFT");
    currentState = "left";
    setFaceWithMode("Walk", FACE_ANIM_LOOP);

    for (int step = 0; step < 4; step++) {

        // Lift left legs, rotate body right (turns robot left)
        setServoAngle(L2, 100);
        setServoAngle(L4, 150);
        delayWithFace(100);

        setServoAngle(L1,  30);   // left-front hip forward
        setServoAngle(L3,  45);   // left-rear hip forward
        setServoAngle(R1, 150);   // right-front hip forward (same dir = rotate)
        setServoAngle(R3, 135);   // right-rear hip forward
        delayWithFace(150);

        setServoAngle(L2, 135);
        setServoAngle(L4, 120);
        delayWithFace(100);

        // Reset hips
        setServoAngle(L1,  45);
        setServoAngle(R1, 135);
        setServoAngle(L3,  60);
        setServoAngle(R3, 120);
        delayWithFace(80);
    }

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

void runTurnRightGait() {

    Serial.println("RIGHT");
    currentState = "right";
    setFaceWithMode("Walk", FACE_ANIM_LOOP);

    for (int step = 0; step < 4; step++) {

        // Lift right legs, rotate body left (turns robot right)
        setServoAngle(R2,  80);
        setServoAngle(R4,  90);
        delayWithFace(100);

        setServoAngle(R1, 150);
        setServoAngle(R3, 135);
        setServoAngle(L1,  30);
        setServoAngle(L3,  45);
        delayWithFace(150);

        setServoAngle(R2,  45);
        setServoAngle(R4,  60);
        delayWithFace(100);

        // Reset hips
        setServoAngle(L1,  45);
        setServoAngle(R1, 135);
        setServoAngle(L3,  60);
        setServoAngle(R3, 120);
        delayWithFace(80);
    }

    runStandPose(true);
    currentState   = "stand";
    currentCommand = "";
}

// ======================================================
//  Command Dispatcher
// ======================================================

void executeCommand(const String &cmd) {

    // --- Behaviors ---
    if      (cmd == "happy")  runHappyPose();
    else if (cmd == "dance")  runDancePose();
    else if (cmd == "angry")  runAngryPose();
    else if (cmd == "sleep")  runSleepPose();
    else if (cmd == "stand")  { currentState = "stand"; setFaceWithMode("stand", FACE_ANIM_LOOP); runStandPose(true); currentCommand = ""; }

    // --- Movement ---
    else if (cmd == "forward")  runForwardGait();
    else if (cmd == "backward") runBackwardGait();
    else if (cmd == "left")     runTurnLeftGait();
    else if (cmd == "right")    runTurnRightGait();
    else if (cmd == "stop")     { currentState = "stand"; setFaceWithMode("stand", FACE_ANIM_LOOP); runStandPose(true); currentCommand = ""; }

    // --- Tools (direct on/off) ---
    else if (cmd == "sprayer_on") {
        Serial.println("SPRAYER ON");
        currentState = "sprayer";
        sprayerOn    = true;
        setFaceWithMode("Sprayer", FACE_ANIM_LOOP);
        digitalWrite(SPRAYER_PIN, HIGH);
        currentCommand = "";
    }
    else if (cmd == "sprayer_off") {
        Serial.println("SPRAYER OFF");
        sprayerOn = false;
        digitalWrite(SPRAYER_PIN, LOW);
        if (currentState == "sprayer") currentState = "stand";
        setFaceWithMode("stand", FACE_ANIM_LOOP);
        currentCommand = "";
    }
    else if (cmd == "cutter_on") {
        Serial.println("CUTTER ON");
        currentState = "cutter";
        cutterOn     = true;
        setFaceWithMode("Cutter", FACE_ANIM_LOOP);
        digitalWrite(CUTTER_IN1, HIGH);
        digitalWrite(CUTTER_IN2, LOW);
        currentCommand = "";
    }
    else if (cmd == "cutter_off") {
        Serial.println("CUTTER OFF");
        cutterOn = false;
        digitalWrite(CUTTER_IN1, LOW);
        digitalWrite(CUTTER_IN2, LOW);
        if (currentState == "cutter") currentState = "stand";
        setFaceWithMode("stand", FACE_ANIM_LOOP);
        currentCommand = "";
    }
    else {
        Serial.print("Unknown command: ");
        Serial.println(cmd);
        currentCommand = "";
    }
}

// ======================================================
//  MQTT Callback
// ======================================================

void mqttCallback(char *topic, byte *payload, unsigned int length) {

    // Convert payload to String
    String msg;
    msg.reserve(length);
    for (unsigned int i = 0; i < length; i++) {
        msg += (char)payload[i];
    }
    msg.toLowerCase();
    msg.trim();

    Serial.print("MQTT << ");
    Serial.print(topic);
    Serial.print(" : ");
    Serial.println(msg);

    String t = String(topic);

    if (t == TOPIC_MOVE || t == TOPIC_BEHAVIOR || t == TOPIC_TOOL) {
        currentCommand = msg;   // picked up in loop()
    }
}

// ======================================================
//  MQTT Connect / Reconnect
// ======================================================

void mqttReconnect() {

    if (mqttClient.connected()) return;

    Serial.print("MQTT connecting as ");
    Serial.print(mqttClientId);
    Serial.println(" ...");

    if (mqttClient.connect(mqttClientId.c_str())) {

        Serial.println("MQTT connected!");

        mqttClient.subscribe(TOPIC_MOVE);
        mqttClient.subscribe(TOPIC_BEHAVIOR);
        mqttClient.subscribe(TOPIC_TOOL);

        Serial.println("Subscribed to spider/* topics");

    } else {
        Serial.print("MQTT failed, rc=");
        Serial.println(mqttClient.state());
    }
}

// ======================================================
//  Telemetry Publisher
// ======================================================

void publishTelemetry() {

    if (!mqttClient.connected()) return;

    String json = "{";
    json += "\"wifi\":\"";
    json += (WiFi.status() == WL_CONNECTED) ? "connected" : "disconnected";
    json += "\",\"state\":\"";
    json += currentState;
    json += "\",\"sprayer\":\"";
    json += sprayerOn ? "on" : "off";
    json += "\",\"cutter\":\"";
    json += cutterOn ? "on" : "off";
    json += "\"}";

    mqttClient.publish(TOPIC_STATUS, json.c_str());
}

// ======================================================
//  WiFi Setup
// ======================================================

void wifiConnect() {

    if (WiFi.status() == WL_CONNECTED) return;

    Serial.print("WiFi connecting to ");
    Serial.println(WIFI_SSID);

    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);

    // Show connecting animation on OLED
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(10, 20);
    display.println("Connecting WiFi...");
    display.display();

    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
        delay(500);
        Serial.print(".");
    }
    Serial.println();

    if (WiFi.status() == WL_CONNECTED) {
        Serial.print("WiFi connected!  IP: ");
        Serial.println(WiFi.localIP());

        // Show IP on OLED
        display.clearDisplay();
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.setCursor(5, 10);
        display.println("WiFi Connected!");
        display.setCursor(5, 30);
        display.print("IP: ");
        display.println(WiFi.localIP());
        display.setCursor(5, 50);
        display.println("Open in browser");
        display.display();
        delay(3000);

    } else {
        Serial.println("WiFi connection FAILED");

        display.clearDisplay();
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.setCursor(10, 25);
        display.println("WiFi FAILED!");
        display.display();
        delay(2000);
    }
}

// ======================================================
//  Setup
// ======================================================

void setup() {

    Serial.begin(115200);
    Serial.println("\n=== Agricultural Spider Robot ===");
    Serial.println("=== IoT Dashboard Integrated  ===\n");

    // --- OLED ---
    Wire.begin();
    if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
        Serial.println("SSD1306 allocation failed");
        while (true);
    }
    display.clearDisplay();
    display.display();

    // --- Servos ---
    for (int i = 0; i < 8; i++) {
        servo[i].setPeriodHertz(50);
        servo[i].attach(servoPins[i], 500, 2400);
    }

    // --- Sprayer & Cutter GPIO ---
    pinMode(SPRAYER_PIN, OUTPUT);
    pinMode(CUTTER_IN1,  OUTPUT);
    pinMode(CUTTER_IN2,  OUTPUT);
    digitalWrite(SPRAYER_PIN, LOW);
    digitalWrite(CUTTER_IN1,  LOW);
    digitalWrite(CUTTER_IN2,  LOW);

    // --- Stand pose on boot ---
    runStandPose(true);

    // --- WiFi ---
    wifiConnect();

    // --- MQTT ---
    mqttClientId  = MQTT_CLIENT;
    mqttClientId += String(random(0xFFFF), HEX);

    mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
    mqttClient.setCallback(mqttCallback);
    mqttClient.setBufferSize(512);
    mqttReconnect();

    // --- Web Server ---
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->send_P(200, "text/html", DASHBOARD_HTML);
    });

    server.begin();
    Serial.println("Web server started on port 80");
    Serial.print("Dashboard: http://");
    Serial.println(WiFi.localIP());
}

// ======================================================
//  Main Loop
// ======================================================

void loop() {

    unsigned long now = millis();

    // --- WiFi auto-reconnect ---
    if (now - lastWifiCheck > WIFI_CHECK_MS) {
        lastWifiCheck = now;
        if (WiFi.status() != WL_CONNECTED) {
            Serial.println("WiFi lost — reconnecting...");
            wifiConnect();
        }
    }

    // --- MQTT keep-alive & reconnect ---
    if (!mqttClient.connected()) {
        mqttReconnect();
    }
    mqttClient.loop();

    // --- Execute pending command ---
    if (currentCommand.length() > 0) {
        String cmd = currentCommand;
        // Don't clear yet — executeCommand() clears it when done
        executeCommand(cmd);
    }

    // --- Publish telemetry periodically ---
    if (now - lastTelemetry > TELEMETRY_MS) {
        lastTelemetry = now;
        publishTelemetry();
    }

    // --- Continuous face animation ---
    updateFaceAnimation();
}
